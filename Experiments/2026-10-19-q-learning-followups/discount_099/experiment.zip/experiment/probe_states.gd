extends SceneTree

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var level := preload("res://Level.tscn").instantiate()
	var agent := preload("res://Agents/QLearningAgent.gd").new()
	level.agent = agent
	level.control_mode = level.ControlMode.Q_LEARNING
	level.headless_training = true
	root.add_child(level)
	level.set_physics_process(false)
	var error := preload("res://Agents/QCheckpoint.gd").load_checkpoint(agent,"res://existing-checkpoint.json")
	assert(error.is_empty(),error)
	var candidates: Array[Vector2] = []
	for child in level.get_children():
		if child is StaticBody2D:
			for offset in [-15.0,0.0,15.0]:
				candidates.append(child.position + Vector2(offset,-32.01))
	var matches: Array = []
	for position in candidates:
		level.reset_episode()
		level.player.reset_to(position)
		for tick in 3:
			await physics_frame
			level.player.set_action(0,false)
			level.player.physics_step(1.0/60.0)
		var state: Dictionary = level.get_state(agent.observation_rays)
		var key: String = agent.State.encode(state)
		if key == "000101|1|1|0":
			matches.append({"x":state.position.x*32,"y":state.position.y*32,"orb_distance":level.player.position.distance_to(level.orb.position),"key":key,"q":agent.values(state)})
	print(JSON.stringify(matches))
	var file := FileAccess.open("res://alias-probe.json",FileAccess.WRITE)
	file.store_string(JSON.stringify(matches,"\t"))
	quit()
