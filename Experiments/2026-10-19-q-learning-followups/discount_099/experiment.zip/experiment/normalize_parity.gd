extends SceneTree

# The diagnostic harness reloads and saves each checkpoint during evaluation.
# Apply the same JSON round trip before comparing the worker's checkpoint.
func _initialize() -> void:
	var agent = preload("res://Agents/QLearningAgent.gd").new()
	var checkpoint = preload("res://Agents/QCheckpoint.gd")
	var error: String = checkpoint.load_checkpoint(agent, "res://parity-checkpoint.json")
	assert(error.is_empty(), error)
	error = checkpoint.save_checkpoint(agent, "res://parity-roundtrip.json")
	assert(error.is_empty(), error)
	quit()
