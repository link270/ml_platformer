extends SceneTree

const Q = preload("res://Agents/QLearningAgent.gd")
const Checkpoint = preload("res://Agents/QCheckpoint.gd")
class ObservedAgent extends "res://Agents/QLearningAgent.gd":
	var decisions: Array = []
	var probe_exploration := false
	func choose_action(state: Dictionary) -> int:
		if probe_exploration: training = true
		var action := super.choose_action(state)
		if probe_exploration: training = false
		if not training:
			var scores := values(state)
			var ties := 0
			for score in scores:
				if score == scores.max(): ties += 1
			decisions.append({"tick":state.tick,"x":state.position.x*32,"y":state.position.y*32,"key":State.encode(state),"action":action,"grounded":state.grounded,"ties":ties,"q":scores.duplicate()})
		return action

var learner = Q.new()
var level
var seed_value := 12345
var output := ""
var results: Dictionary = {"training":[],"evaluations":[]}
var started := 0

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var args := OS.get_cmdline_user_args()
	seed_value = int(args[0])
	output = "res://results-%d.json" % seed_value
	learner.rng.seed = seed_value
	started = Time.get_ticks_msec()
	level = preload("res://Level.tscn").instantiate()
	level.agent = learner
	level.control_mode = level.ControlMode.Q_LEARNING
	level.headless_training = true
	root.add_child(level)
	level.set_physics_process(false)
	results.seed = seed_value
	results.source = JSON.parse_string(FileAccess.get_file_as_string("res://source-fingerprints.json"))
	if args.size() > 1:
		var error := Checkpoint.load_checkpoint(learner, args[1])
		assert(error.is_empty(), error)
		results.loaded_checkpoint = args[1]
		await evaluate(learner.training_episodes)
		save_results()
		quit()
		return
	for milestone in [0,100,300,600,1000,2000,3000,5000,10000]:
		while learner.training_episodes < milestone:
			await physics_frame
			level._physics_process(1.0 / 60.0)
			if level.done:
				results.training.append({"episode":learner.training_episodes,"ticks":level.player.tick,"win":level.orb_collected,"timeout":level.timed_out,"return":level.last_episode_return,"rows":learner.q_table.size()})
		var error := Checkpoint.save_checkpoint(learner,"res://checkpoint-%d-%d.json" % [seed_value,milestone])
		assert(error.is_empty(), error)
		print("TRAIN seed=%d episodes=%d wins=%d rows=%d" % [seed_value,milestone,learner.training_wins,learner.q_table.size()])
		save_results()
	for milestone in [0,100,300,600,1000,2000,3000,5000,10000]:
		var error := Checkpoint.load_checkpoint(learner,"res://checkpoint-%d-%d.json" % [seed_value,milestone])
		assert(error.is_empty(),error)
		await evaluate(milestone)
		save_results()
	print("DONE seed ",seed_value," seconds ",(Time.get_ticks_msec()-started)/1000.0)
	quit()

func evaluate(milestone: int) -> void:
	var evaluator := ObservedAgent.new()
	evaluator.training = false
	evaluator.probe_exploration = true
	evaluator.epsilon = 0.05
	evaluator.q_table = learner.q_table.duplicate(true)
	# Identical tie-breaking stream at each checkpoint; training RNG is untouched.
	evaluator.rng.seed = seed_value + 1000000
	var original_rng: int = learner.rng.state
	var original_hash := var_to_bytes(learner.q_table).hex_encode().sha256_text()
	level.agent = evaluator
	var evaluation := {"episode":milestone,"epsilon":learner.epsilon,"rows":learner.q_table.size(),"runs":[]}
	for i in 100:
		level.reset_episode()
		evaluator.decisions.clear()
		var jumps := 0
		var still_ticks := 0
		var longest_still := 0
		var still_streak := 0
		while not level.done:
			await physics_frame
			var previous: Vector2 = level.player.position
			var grounded: bool = level.player._grounded_ready and level.player.is_on_floor()
			level._physics_process(1.0 / 60.0)
			if grounded and level.player.velocity.y < 0: jumps += 1
			if previous.distance_to(level.player.position) < 0.01:
				still_ticks += 1
				still_streak += 1
				longest_still = maxi(longest_still,still_streak)
			else: still_streak = 0
		var counts := [0,0,0,0,0,0]
		var grounded_counts := [0,0,0,0,0,0]
		var occupancy := {}
		var tied := 0
		var trace: Array = evaluator.decisions.duplicate(true)
		for decision in trace:
			counts[decision.action] += 1
			if decision.grounded: grounded_counts[decision.action] += 1
			if decision.ties > 1: tied += 1
			var cell := "%d,%d" % [roundi(decision.x/16),roundi(decision.y/16)]
			occupancy[cell] = occupancy.get(cell,0) + 1
		var run := {"win":level.orb_collected,"timeout":level.timed_out,"ticks":level.player.tick,"return":level.last_episode_return,"end_x":level.player.position.x,"end_y":level.player.position.y,"jumps":jumps,"still_ticks":still_ticks,"longest_still_ticks":longest_still,"actions":counts,"grounded_actions":grounded_counts,"tied_decisions":tied,"occupancy":occupancy}
		if i < 3: run.trace = trace
		evaluation.runs.append(run)
	assert(learner.rng.state == original_rng)
	assert(var_to_bytes(learner.q_table).hex_encode().sha256_text() == original_hash)
	results.evaluations.append(evaluation)
	var wins := 0
	var timeouts := 0
	for run in evaluation.runs:
		wins += int(run.win)
		timeouts += int(run.timeout)
	print("seed=%d episode=%d eval wins=%d/100 timeout=%d rows=%d" % [seed_value,milestone,wins,timeouts,learner.q_table.size()])
	var error := Checkpoint.save_checkpoint(learner,"res://checkpoint-%d-%d.json" % [seed_value,milestone])
	assert(error.is_empty(), error)
	level.agent = learner
	level.reset_episode()

func save_results() -> void:
	results.seconds = (Time.get_ticks_msec()-started)/1000.0
	var file := FileAccess.open(output,FileAccess.WRITE)
	file.store_string(JSON.stringify(results))
